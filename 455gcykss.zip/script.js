```javascript
var account = null;
var students = [];


// ===============================
// LOAD SAVED DATA
// ===============================

var savedAccount = localStorage.getItem("studentAccount");

if (savedAccount) {
    account = JSON.parse(savedAccount);
}


var savedStudents = localStorage.getItem("students");

if (savedStudents) {
    students = JSON.parse(savedStudents);
}


// ===============================
// PAGE FUNCTIONS
// ===============================

function hideAllPages() {

    document.getElementById("registerPage").classList.remove("active");

    document.getElementById("loginPage").classList.remove("active");

    document.getElementById("studentPage").classList.remove("active");
}


function showRegister() {

    hideAllPages();

    document.getElementById("registerPage").classList.add("active");
}


function showLogin() {

    hideAllPages();

    document.getElementById("loginPage").classList.add("active");
}


function showStudentPage() {

    hideAllPages();

    document.getElementById("studentPage").classList.add("active");

    displayStudents();
}


// ===============================
// REGISTER ACCOUNT
// ===============================

document.getElementById("registerForm").addEventListener("submit", function(event) {

    event.preventDefault();

    var name = document.getElementById("registerName").value.trim();

    var email = document.getElementById("registerEmail").value.trim();

    var password = document.getElementById("registerPassword").value;

    var confirmPassword = document.getElementById("confirmPassword").value;


    if (password !== confirmPassword) {

        alert("Passwords do not match.");

        return;
    }


    if (account !== null) {

        if (account.email.toLowerCase() === email.toLowerCase()) {

            alert("Account already exists. Please login.");

            showLogin();

            return;
        }
    }


    account = {

        name: name,

        email: email,

        password: password
    };


    localStorage.setItem(
        "studentAccount",
        JSON.stringify(account)
    );


    alert("Registration successful! Now login.");

    document.getElementById("registerForm").reset();

    showLogin();

});


// ===============================
// LOGIN
// ===============================

document.getElementById("loginForm").addEventListener("submit", function(event) {

    event.preventDefault();

    var email = document.getElementById("loginEmail").value.trim();

    var password = document.getElementById("loginPassword").value;


    if (account === null) {

        alert("No account found. Please register first.");

        showRegister();

        return;
    }


    if (
        email.toLowerCase() !== account.email.toLowerCase() ||
        password !== account.password
    ) {

        alert("Wrong email or password.");

        return;
    }


    localStorage.setItem("loggedIn", "true");

    alert("Login successful!");

    document.getElementById("loginForm").reset();

    showStudentPage();

});


// ===============================
// REGISTER STUDENT
// ===============================

document.getElementById("studentForm").addEventListener("submit", function(event) {

    event.preventDefault();


    var name = document.getElementById("studentName").value.trim();

    var department = document.getElementById("department").value;

    var rollNumber = document.getElementById("rollNumber").value.trim();

    var phone = document.getElementById("phone").value.trim();

    var cgpa = document.getElementById("cgpa").value;

    var year = document.getElementById("year").value;


    if (name === "") {

        alert("Please enter student name.");

        return;
    }


    if (department === "") {

        alert("Please select department.");

        return;
    }


    if (rollNumber === "") {

        alert("Please enter roll number.");

        return;
    }


    if (!/^[0-9]{10}$/.test(phone)) {

        alert("Phone number must contain exactly 10 digits.");

        return;
    }


    var cgpaNumber = Number(cgpa);


    if (cgpaNumber < 0 || cgpaNumber > 10) {

        alert("CGPA must be between 0 and 10.");

        return;
    }


    if (year === "") {

        alert("Please select year.");

        return;
    }


    // Check duplicate roll number

    var duplicate = false;

    for (var i = 0; i < students.length; i++) {

        if (
            students[i].rollNumber.toLowerCase() ===
            rollNumber.toLowerCase()
        ) {

            duplicate = true;

            break;
        }
    }


    if (duplicate) {

        alert("This roll number is already registered.");

        return;
    }


    // Create student

    var student = {

        name: name,

        department: department,

        rollNumber: rollNumber,

        phone: phone,

        cgpa: cgpaNumber.toFixed(2),

        year: year
    };


    // Add student

    students.push(student);


    // Save student

    localStorage.setItem(
        "students",
        JSON.stringify(students)
    );


    alert("Student registered successfully!");


    document.getElementById("studentForm").reset();


    displayStudents();

});


// ===============================
// DISPLAY STUDENTS
// ===============================

function displayStudents() {

    var tableBody =
        document.getElementById("studentTableBody");

    var studentCount =
        document.getElementById("studentCount");


    studentCount.textContent = students.length;


    tableBody.innerHTML = "";


    if (students.length === 0) {

        var emptyRow = document.createElement("tr");

        var emptyCell = document.createElement("td");

        emptyCell.colSpan = 8;

        emptyCell.className = "empty-row";

        emptyCell.textContent = "No students registered yet.";

        emptyRow.appendChild(emptyCell);

        tableBody.appendChild(emptyRow);

        return;
    }


    for (var i = 0; i < students.length; i++) {

        var student = students[i];

        var row = document.createElement("tr");


        var cell1 = document.createElement("td");

        cell1.textContent = i + 1;


        var cell2 = document.createElement("td");

        cell2.textContent = student.name;


        var cell3 = document.createElement("td");

        cell3.textContent = student.department;


        var cell4 = document.createElement("td");

        cell4.textContent = student.rollNumber;


        var cell5 = document.createElement("td");

        cell5.textContent = student.phone;


        var cell6 = document.createElement("td");

        cell6.textContent = student.cgpa;


        var cell7 = document.createElement("td");

        cell7.textContent = student.year;


        var cell8 = document.createElement("td");


        var deleteButton =
            document.createElement("button");

        deleteButton.textContent = "Delete";

        deleteButton.className = "delete-btn";


        deleteButton.onclick = function(index) {

            return function() {

                deleteStudent(index);

            };

        }(i);


        cell8.appendChild(deleteButton);


        row.appendChild(cell1);

        row.appendChild(cell2);

        row.appendChild(cell3);

        row.appendChild(cell4);

        row.appendChild(cell5);

        row.appendChild(cell6);

        row.appendChild(cell7);

        row.appendChild(cell8);


        tableBody.appendChild(row);
    }
}


// ===============================
// DELETE STUDENT
// ===============================

function deleteStudent(index) {

    var answer =
        confirm("Do you want to delete this student?");


    if (answer === true) {

        students.splice(index, 1);


        localStorage.setItem(
            "students",
            JSON.stringify(students)
        );


        displayStudents();
    }
}


// ===============================
// LOGOUT
// ===============================

function logout() {

    localStorage.removeItem("loggedIn");

    showLogin();
}


// ===============================
// START APPLICATION
// ===============================

window.addEventListener("load", function() {

    var loggedIn =
        localStorage.getItem("loggedIn");


    if (loggedIn === "true") {

        showStudentPage();

    } else {

        showRegister();
    }

});
```
